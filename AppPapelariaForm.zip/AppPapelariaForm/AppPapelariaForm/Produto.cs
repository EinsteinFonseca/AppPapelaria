﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppPapelariaForm
{
    internal class Produto
    {
        public string categoria { get; set; }
        public string Nome { get; set; }
        public double Preco { get; set; }
        public int quantidade { get; set; }
    }
}
